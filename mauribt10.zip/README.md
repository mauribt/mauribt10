<p align="center">
<img src="https://3rdworldgeeks.files.wordpress.com/2020/10/uzaki-chan.gif" width="539" height="539"/>
</p>

# 🖤MeliodasBot06💥

#### WhatsApp Bot

## 🔥MΣᄂIӨDΛƧ❤


### TERMUX ✔
```bash
> pkg update && pkg upgrade
> pkg install git -y
> git clone https://github.com/MeliodasJAJA/MeliodasBot06
> cd MeliodasBot06
> bash install.sh 
```
#### Run👌👍
```bash
> node index.js
```

---------
## ❤Gracias por usar🖤 ⚜🟢MeliodasBot^^❤✅
